# Changelog - ansible-role-httpd - Acropia.nl
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)  
Format: https://keepachangelog.com/en/1.0.0/

## [Unreleased]
### Added
### Changed
### Deprecated
### Removed
### Fixed
### Security

## [0.1] - 2022-03-18
### Added
- Hello World!
- Initial commit extracting httpd features to a separate role